<footer class="footer">
    <div class="footer-container">
        <div class="footer-content">
            <p class="m-0">&copy; 2024 Kementerian Pekerjaan Umum. All rights reserved.</p>
        </div>
    </div>
</footer>